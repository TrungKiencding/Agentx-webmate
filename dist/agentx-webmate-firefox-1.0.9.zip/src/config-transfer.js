import {
  CUSTOM_SKILLS_STORAGE_KEY,
  DEFAULT_SKILLS_REMOVED_STORAGE_KEY,
} from './agent/skills.js';
import {
  USER_MEMORY_AUTO_CAPTURE_KEY,
  USER_MEMORY_DEFAULT_MAX_PROMPT_CHARS,
  USER_MEMORY_ENABLED_KEY,
  USER_MEMORY_FORM_CAPTURE_KEY,
  USER_MEMORY_MAX_PROMPT_CHARS_KEY,
  USER_MEMORY_STORAGE_KEY,
} from './agent/user-memory.js';
import {
  DEFAULT_PERMISSION_MODE,
  LEGACY_PERMISSION_GATE_KEY,
  PERMISSION_MODE_STORAGE_KEY,
  legacyGateValueForMode,
  normalizePermissionMode,
  permissionModeFromLegacyGate,
} from './agent/permission-mode.js';
import { AUTO_GROUP_TABS_KEY } from './tab-group-preference.js';

export const CONFIG_SCHEMA = 'webbrain-config/1';
export const MAX_CONFIG_IMPORT_CHARS = 10_000_000;

// This is intentionally an allowlist of user-controlled Settings state. It
// excludes conversations, traces, schedules, usage counters, the AgentX WebMate
// Cloud device ID.
export const DEFAULT_CONFIG_SETTINGS = Object.freeze({
  wbLocale: 'vi',
  themeMode: 'system',
  verboseMode: false,
  selectionShortcutEnabled: true,
  [AUTO_GROUP_TABS_KEY]: true,
  screenshotFallback: true,
  maxAgentSteps: 130,
  requestTimeoutMs: 120_000,
  clarifyTimeoutSec: 60,
  clarifyTimeoutSemanticsV2: true,
  autoScreenshot: 'state_change',
  useSiteAdapters: true,
  voiceInputEnabled: true,
  alwaysAllowApiMutations: false,
  apiMutationObserverEnabled: false,
  webMcpEnabled: false,
  openaiAskStreamingEnabled: true,
  planBeforeActMode: 'try',
  planBeforeAct: true,
  planReviewMode: 'confidence',
  planReviewConfidenceThreshold: 75,
  downloadDirectory: '',
  notifySound: true,
  completionConfetti: true,
  tracingEnabled: false,
  strictSecretMode: false,
  agentAllowLocalNetwork: false,
  scheduledTasksEnabled: true,
  scheduledRequireConsequentialConfirmation: true,
  providerFilter: 'all',
  screenshotRedaction: false,
  [PERMISSION_MODE_STORAGE_KEY]: DEFAULT_PERMISSION_MODE,
  // Kept in the snapshot purely as the pre-modes MIRROR of permissionMode, so
  // a file written here still lands correctly in a build that predates modes
  // (and a file written there still imports here). reconcilePermissionMode
  // below keeps the two from ever disagreeing; runtime code reads only
  // permissionMode.
  [LEGACY_PERMISSION_GATE_KEY]: true,
  wb_permissions: [],
  providers: {},
  activeProvider: 'webbrain_cloud',
  visionModel: null,
  transcriptionModel: null,
  profileEnabled: false,
  profileText: '',
  [USER_MEMORY_STORAGE_KEY]: { version: 1, records: [] },
  [USER_MEMORY_ENABLED_KEY]: true,
  [USER_MEMORY_AUTO_CAPTURE_KEY]: false,
  [USER_MEMORY_FORM_CAPTURE_KEY]: false,
  [USER_MEMORY_MAX_PROMPT_CHARS_KEY]: USER_MEMORY_DEFAULT_MAX_PROMPT_CHARS,
  [CUSTOM_SKILLS_STORAGE_KEY]: [],
  [DEFAULT_SKILLS_REMOVED_STORAGE_KEY]: [],
  enableAllPackagedSkills: false,
  captchaSolverEnabled: false,
  capsolverApiKey: '',
});

export const CONFIG_STORAGE_KEYS = Object.freeze(Object.keys(DEFAULT_CONFIG_SETTINGS));
const CONFIG_STORAGE_KEY_SET = new Set(CONFIG_STORAGE_KEYS);

const BOOLEAN_KEYS = new Set([
  'verboseMode',
  'selectionShortcutEnabled',
  AUTO_GROUP_TABS_KEY,
  'screenshotFallback',
  'clarifyTimeoutSemanticsV2',
  'useSiteAdapters',
  'voiceInputEnabled',
  'alwaysAllowApiMutations',
  'apiMutationObserverEnabled',
  'webMcpEnabled',
  'openaiAskStreamingEnabled',
  'planBeforeAct',
  'notifySound',
  'completionConfetti',
  'tracingEnabled',
  'strictSecretMode',
  'agentAllowLocalNetwork',
  'scheduledTasksEnabled',
  'scheduledRequireConsequentialConfirmation',
  'screenshotRedaction',
  LEGACY_PERMISSION_GATE_KEY,
  'profileEnabled',
  USER_MEMORY_ENABLED_KEY,
  USER_MEMORY_AUTO_CAPTURE_KEY,
  USER_MEMORY_FORM_CAPTURE_KEY,
  'enableAllPackagedSkills',
  'captchaSolverEnabled',
]);
const NUMBER_KEYS = new Set([
  'maxAgentSteps',
  'requestTimeoutMs',
  'clarifyTimeoutSec',
  'planReviewConfidenceThreshold',
  USER_MEMORY_MAX_PROMPT_CHARS_KEY,
]);
const STRING_KEYS = new Set([
  'wbLocale',
  PERMISSION_MODE_STORAGE_KEY,
  'themeMode',
  'autoScreenshot',
  'planBeforeActMode',
  'planReviewMode',
  'downloadDirectory',
  'providerFilter',
  'activeProvider',
  'profileText',
  'capsolverApiKey',
]);
const ARRAY_KEYS = new Set([
  'wb_permissions',
  CUSTOM_SKILLS_STORAGE_KEY,
  DEFAULT_SKILLS_REMOVED_STORAGE_KEY,
]);
const NULLABLE_OBJECT_KEYS = new Set(['visionModel', 'transcriptionModel']);

function isPlainObject(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}

function clone(value) {
  return structuredClone(value);
}

function sanitizeProviders(value, { strict = false } = {}) {
  if (!isPlainObject(value)) return {};
  const providers = clone(value);
  for (const [id, config] of Object.entries(providers)) {
    if (!isPlainObject(config)) {
      if (strict) throw new Error(`Invalid provider configuration "${id}".`);
      delete providers[id];
      continue;
    }
    delete config.deviceGuid;
  }
  return providers;
}

function validSettingValue(key, value) {
  if (BOOLEAN_KEYS.has(key)) return typeof value === 'boolean';
  if (NUMBER_KEYS.has(key)) return typeof value === 'number' && Number.isFinite(value);
  if (STRING_KEYS.has(key)) return typeof value === 'string';
  if (ARRAY_KEYS.has(key)) return Array.isArray(value);
  if (NULLABLE_OBJECT_KEYS.has(key)) return value === null || isPlainObject(value);
  if (key === 'providers' || key === USER_MEMORY_STORAGE_KEY) return isPlainObject(value);
  return true;
}

/**
 * Settle permissionMode against its legacy mirror. An export written by a
 * build that predates modes carries only the boolean, so honour it; anything
 * carrying the mode lets the mode win. The mirror is then always rewritten
 * FROM the resolved mode, so the two can never travel in disagreement.
 */
function reconcilePermissionMode(settings, source) {
  const hasMode = isPlainObject(source) && Object.hasOwn(source, PERMISSION_MODE_STORAGE_KEY)
    && typeof source[PERMISSION_MODE_STORAGE_KEY] === 'string';
  const mode = hasMode
    ? normalizePermissionMode(source[PERMISSION_MODE_STORAGE_KEY])
    : permissionModeFromLegacyGate(
      isPlainObject(source) ? source[LEGACY_PERMISSION_GATE_KEY] : undefined,
    );
  settings[PERMISSION_MODE_STORAGE_KEY] = mode;
  settings[LEGACY_PERMISSION_GATE_KEY] = legacyGateValueForMode(mode);
  return settings;
}

function normalizeSettings(source, { strict = false } = {}) {
  const settings = clone(DEFAULT_CONFIG_SETTINGS);
  if (!isPlainObject(source)) {
    if (strict) throw new Error('Configuration settings must be a JSON object.');
    return settings;
  }

  for (const key of CONFIG_STORAGE_KEYS) {
    if (!Object.hasOwn(source, key)) continue;
    const value = source[key];
    if (!validSettingValue(key, value)) {
      if (strict) throw new Error(`Invalid value for configuration setting "${key}".`);
      continue;
    }
    settings[key] = clone(value);
  }
  settings.providers = sanitizeProviders(settings.providers, { strict });
  return reconcilePermissionMode(settings, source);
}

export function createConfigExport(stored = {}, options = {}) {
  const settings = normalizeSettings(stored);
  if (typeof options.locale === 'string' && options.locale) settings.wbLocale = options.locale;
  return {
    schema: CONFIG_SCHEMA,
    exportedAt: new Date(options.exportedAt ?? Date.now()).toISOString(),
    webbrainVersion: String(options.webbrainVersion || 'unknown'),
    warning: 'Contains plaintext provider API keys and other sensitive Settings data. Store securely.',
    settings,
  };
}

export function parseConfigImport(json) {
  const text = String(json || '');
  if (text.length > MAX_CONFIG_IMPORT_CHARS) throw new Error('Configuration JSON is too large.');
  if (!text.trim()) throw new Error('Paste configuration JSON or use /import --file.');

  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    throw new Error('Configuration is not valid JSON.');
  }
  if (!isPlainObject(parsed) || parsed.schema !== CONFIG_SCHEMA) {
    throw new Error(`Expected a ${CONFIG_SCHEMA} export.`);
  }
  if (!isPlainObject(parsed.settings)) {
    throw new Error('Configuration settings must be a JSON object.');
  }

  return {
    settings: normalizeSettings(parsed.settings, { strict: true }),
    ignoredKeys: Object.keys(parsed.settings).filter((key) => !CONFIG_STORAGE_KEY_SET.has(key)),
    sourceVersion: typeof parsed.webbrainVersion === 'string' ? parsed.webbrainVersion : '',
  };
}

// Provisioning can apply an already-sanitized export as a sparse patch. Unlike
// the user-facing restore command above, omitted settings remain untouched.
export function parseConfigPatchImport(json) {
  const text = String(json || '');
  if (text.length > MAX_CONFIG_IMPORT_CHARS) throw new Error('Configuration JSON is too large.');
  if (!text.trim()) throw new Error('Paste configuration JSON or use /import --file.');

  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    throw new Error('Configuration is not valid JSON.');
  }
  if (!isPlainObject(parsed) || parsed.schema !== CONFIG_SCHEMA) {
    throw new Error(`Expected a ${CONFIG_SCHEMA} export.`);
  }
  if (!isPlainObject(parsed.settings)) {
    throw new Error('Configuration settings must be a JSON object.');
  }

  const settings = {};
  const ignoredKeys = [];
  for (const [key, value] of Object.entries(parsed.settings)) {
    if (!CONFIG_STORAGE_KEY_SET.has(key)) {
      ignoredKeys.push(key);
      continue;
    }
    if (!validSettingValue(key, value)) {
      throw new Error(`Invalid value for configuration setting "${key}".`);
    }
    settings[key] = key === 'providers'
      ? sanitizeProviders(value, { strict: true })
      : clone(value);
  }
  // A PATCH is sparse, so reconcilePermissionMode's full-snapshot logic does
  // not apply. Two fixes are still needed here: normalize an explicit mode,
  // and derive one from a patch that carries only the pre-modes boolean —
  // runtime code reads permissionMode, so such a patch would otherwise be
  // silently ignored on any install that already migrated.
  if (typeof settings[PERMISSION_MODE_STORAGE_KEY] === 'string') {
    settings[PERMISSION_MODE_STORAGE_KEY] = normalizePermissionMode(settings[PERMISSION_MODE_STORAGE_KEY]);
  } else if (Object.hasOwn(settings, LEGACY_PERMISSION_GATE_KEY)) {
    settings[PERMISSION_MODE_STORAGE_KEY] = permissionModeFromLegacyGate(settings[LEGACY_PERMISSION_GATE_KEY]);
  }
  return {
    settings,
    ignoredKeys,
    sourceVersion: typeof parsed.webbrainVersion === 'string' ? parsed.webbrainVersion : '',
  };
}

export function mergeConfigPatchSettings(current = {}, patch = {}) {
  const merged = clone(patch);
  if (!Object.hasOwn(merged, 'providers')) return merged;
  const currentProviders = isPlainObject(current.providers) ? clone(current.providers) : {};
  const patchProviders = isPlainObject(merged.providers) ? merged.providers : {};
  // Cloud provisioning owns this provider's credentials, endpoint and device
  // identity. A portable export may contain a stale copy, so never let it
  // replace the runtime's current AgentX WebMate Cloud configuration.
  delete patchProviders.webbrain_cloud;
  merged.providers = { ...currentProviders, ...patchProviders };
  return merged;
}
