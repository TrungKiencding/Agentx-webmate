import {
  compileSuccessfulWorkflowByRunId,
  normalizeSavedWorkflow,
} from './agent/workflows.js';
import { isCredentialField } from './agent/credential-fields.js';
import { PERMISSION_MODES } from './agent/permission-mode.js';
import {
  CLOUD_BRIDGE_ENABLED_KEY,
  CLOUD_BRIDGE_URL_KEY,
  DEFAULT_CLOUD_BRIDGE_URL,
  WORKMATE_CONFIG_PATH,
  WORKMATE_INSTANCE_ID_KEY,
  WORKMATE_SESSION_STORAGE_KEY,
  cloudBridgeUrlFrom,
  isCloudBridgeEnabled,
  parseWorkmateConfig,
} from './cloud-bridge-config.js';
const CLOUD_RUN_STORAGE_KEY = 'webbrainCloudRunSnapshots';
const CLOUD_UPDATE_LIMIT = 200;
const CLOUD_RUN_LIMIT = 50;
const CLOUD_STRING_LIMIT = 16 * 1024;
const CLOUD_RUN_PERSIST_BYTES_LIMIT = 256 * 1024;
const CLOUD_PERSIST_BYTES_LIMIT = 4 * 1024 * 1024;
const TERMINAL_STATUSES = new Set(['completed', 'failed', 'aborted']);
// Suffix match on normalized keys (non-alnum stripped). Avoid bare `pin` as a
// suffix — it over-matches `spin`, `mapPin`, etc. Short exact keys live in the set.
const SENSITIVE_CLOUD_KEY = /(?:authorization|cookie|password|passwd|passphrase|passcode|pincode|(?:verification|confirmation|security|auth|email|twofactor|2fa|mfa|onetime|recovery)code|secret|credential|privatekey|apikey|token|accesskeyid|secretaccesskey)$/i;
const SENSITIVE_CLOUD_KEY_EXACT = new Set(['code', 'pin', 'otp', 'cvv', 'cvc', 'ssn']);
const LARGE_IMAGE_KEY = /(?:attachimage|screenshot|image|imagedata|dataurl)$/i;
const CLOUD_TEXT_ENTRY_TOOLS = new Set(['set_field', 'type_ax', 'type_text', 'iframe_type']);
const VERIFY_FORM_VALUE_KEYS = new Set(['value', 'controlvalue', 'valueprefix', 'valuesuffix']);
// Strict-secret mode is deny-by-default: an update leaves the browser carrying
// only the evidence a cloud caller needs to score the run. A per-tool allowlist
// is the wrong shape here — a secret typed into a visible field comes straight
// back out of the next page read, and model prose repeats it in plain text.
// These are the narrow carve-outs that survive, keyed by what grading reads.
const CLOUD_STRICT_MODEL_TEXT_TYPES = new Set(['text', 'text_delta']);
// `error` and `run_status` carry the model's final response as `message`.
const CLOUD_STRICT_DROPPED_MESSAGE_TYPES = new Set(['error', 'run_status']);
// done_json and verify_form keep their shape through dedicated value-level
// redactors below; every other tool result is reduced to a bare envelope.
const CLOUD_STRICT_STRUCTURED_RESULT_TOOLS = new Set(['done_json', 'verify_form']);
// Scalar, non-page-derived argument keys. `fetch_url` is handled separately so
// its URL is reduced to origin-only evidence rather than dropped.
const CLOUD_STRICT_ARG_EVIDENCE_KEYS = new Set(['skill_id', 'method', 'url_origin']);
// A caller has to read a clarification to answer it, so `clarify` cannot be
// blanked the way model prose is. Prompt instructions are not a redaction
// boundary either, so strict runs additionally redact by *value*: every secret
// this run typed into a page is remembered and struck from the text of every
// later update, clarifications included. That leaves a usable question while
// removing the literal the key-based scrubber cannot recognize.
const CLOUD_STRICT_SECRET_VALUE_LIMIT = 256;
// Short values would mangle ordinary prose on a coincidental substring match.
// Numeric PIN/CVV fragments are still security-sensitive, so they are tracked
// with boundary-aware replacement below.
const CLOUD_STRICT_SECRET_MIN_LENGTH = 4;
const WORKFLOW_PARAMETER_VALUE_LIMIT = 10_000;
const SENSITIVE_URL_COMPONENT_KEY = /(?:^|[-_.\s])(?:auth(?:orization)?|api[-_.\s]?key|key|token|secret|signature|sig|code|credential|password|passcode|otp)(?:$|[-_.\s])/i;
const SENSITIVE_URL_PATH_LABELS = new Set([
  'auth', 'authorization', 'apikey', 'key', 'token', 'accesstoken', 'refreshtoken',
  'secret', 'signature', 'sig', 'code', 'authcode', 'verificationcode',
  'credential', 'password', 'passcode', 'otp', 'downloadkey', 'sharetoken',
]);

function cloudRunError(message, status, extra = {}) {
  return Object.assign(new Error(message), { status }, extra);
}

/**
 * Asks the embedder's run gate whether a run may start; a refusal comes back
 * as the error to throw. The gate is the brand's policy (AgentX: a read-only
 * license refuses with code `license_read_only` and the license itself, which
 * the background passes on to the bridge so Workmate can say why). It is
 * advisory plumbing, never a new way to fail: a gate that throws, or answers
 * something that is not a refusal, lets the run start.
 */
async function runGateRefusal(runGate) {
  if (typeof runGate !== 'function') return null;
  let verdict;
  try {
    verdict = await runGate();
  } catch {
    return null;
  }
  if (!verdict || typeof verdict !== 'object') return null;
  const message = String(verdict.message || '').trim();
  if (!message) return null;
  const status = Number.isInteger(verdict.status) && verdict.status >= 400 && verdict.status < 600
    ? verdict.status
    : 403;
  return cloudRunError(message, status, {
    ...(typeof verdict.code === 'string' && verdict.code ? { code: verdict.code } : {}),
    ...(verdict.license && typeof verdict.license === 'object' ? { license: verdict.license } : {}),
  });
}

export function normalizeCloudRunMode(value, fallback = 'act') {
  const mode = String(value ?? '').trim().toLowerCase();
  if (!mode) return fallback;
  if (!['ask', 'act'].includes(mode)) {
    throw cloudRunError('Cloud run `mode` must be `ask` or `act`.', 400);
  }
  return mode;
}

/**
 * The permission mode one cloud run executes at, or '' when the caller named
 * none (then the browser's standing mode applies, exactly as before).
 *
 * A delegated run needs its own mode because the caller on the other end of the
 * bridge is the one who answers permission cards; leaving it on the standing
 * mode meant the only ways to run a task unattended were to strip the gate from
 * the user's own browsing, or to have the caller auto-answer `always` — which
 * writes real, persistent grants for hosts the user never approved. Naming the
 * mode is the honest version of both.
 *
 * Junk THROWS rather than normalizing. `resolveRunPermissionMode` fails safe to
 * `manual`, so a caller that misspelled `bypass` would otherwise get a run that
 * stops at every card with nothing to explain why; 400 names the typo instead.
 * Case is folded first because this arrives from another program's config, not
 * from storage — `BYPASS` is a spelling, not an attack.
 */
function normalizeCloudRunPermissionMode(value) {
  const mode = String(value ?? '').trim().toLowerCase();
  if (!mode) return '';
  if (!PERMISSION_MODES.includes(mode)) {
    throw cloudRunError(
      `Cloud run \`permission_mode\` must be one of: ${PERMISSION_MODES.join(', ')}.`,
      400,
    );
  }
  return mode;
}

/**
 * The mode for THIS run: what the caller asked for, else what the run it
 * continues was granted, else '' for the browser's standing mode.
 *
 * A continuation inherits for the same reason it inherits `mode`: resuming a
 * delegated run is the same run, and having it start raising cards halfway
 * through would strand it on a caller that had already been told it would not
 * be asked.
 */
function cloudRunPermissionMode(msg, parentRun) {
  const requested = normalizeCloudRunPermissionMode(msg.permissionMode ?? msg.permission_mode);
  return requested || parentRun?.permissionMode || '';
}

/**
 * Why the browser cannot answer a model right now, or '' when it can.
 *
 * A cloud run used to sail past this and die at its first completion with
 * whatever the provider said — a 401, or a complaint about an empty model —
 * which reads as a broken bridge rather than as "nobody has signed in yet".
 * The managed cloud provider ships with no key and no model until a sign-in
 * installs them, so on a browser whose side panel has never been opened this is
 * the state EVERY delegated run starts in.
 *
 * Deliberately asked of the provider's own declared requirements rather than of
 * any particular provider id: an install driven by a hand-configured provider
 * gets the same answer for the same reason, and upstream builds whose managed
 * provider ships a working default are unaffected.
 */
function describeUnusableProvider(agent) {
  const providerManager = agent?.providerManager;
  // Only POSITIVE evidence refuses a run. With nothing to ask, an undiagnosable
  // browser has to fail the way it always did — at the first completion — rather
  // than gain a refusal invented by a check that could not actually check.
  if (typeof providerManager?.getActive !== 'function') return '';
  let provider;
  try {
    provider = providerManager.getActive();
  } catch {
    // getActive throws for exactly one reason: the selected provider is gone.
    return 'AgentX WebMate has no active model provider. Open its side panel and sign in, then start the run again.';
  }
  if (!provider) return '';
  const config = provider.config || {};
  const label = config.label || provider.name || 'The active provider';
  const missing = config.requiresApiKey && !String(config.apiKey || '').trim()
    ? 'API key'
    : config.requiresModel && !String(config.model || '').trim()
      ? 'model'
      : '';
  if (!missing) return '';
  return `AgentX WebMate cannot run this task: ${label} has no ${missing} yet. `
    + 'Open the AgentX WebMate side panel and sign in — or choose a provider in its Settings — '
    + 'then start the run again.';
}

function normalizedCloudKey(key) {
  return String(key || '').replace(/[^a-z0-9]/gi, '');
}

export function normalizeCloudBridgeUrl(value = DEFAULT_CLOUD_BRIDGE_URL) {
  const url = new URL(String(value || DEFAULT_CLOUD_BRIDGE_URL));
  const host = url.hostname.toLowerCase();
  // WHATWG URL keeps the brackets on IPv6 literals: ws://[::1]/… parses to
  // hostname "[::1]", so both spellings must be allowlisted (same as
  // LOCAL_OLLAMA_HOSTS in ollama-handoff.js).
  if (url.protocol !== 'ws:' || !['127.0.0.1', 'localhost', '::1', '[::1]'].includes(host)) {
    throw new Error('AgentX WebMate cloud bridge URL must use ws:// on localhost.');
  }
  return url.href;
}

export function isSensitiveCloudKey(key) {
  const normalizedKey = normalizedCloudKey(key);
  if (!normalizedKey) return false;
  return SENSITIVE_CLOUD_KEY.test(normalizedKey) || SENSITIVE_CLOUD_KEY_EXACT.has(normalizedKey);
}

function hasCloudOutputSchema(value) {
  return value !== null && value !== undefined;
}

function scrubCloudValue(value) {
  try {
    return JSON.parse(JSON.stringify(value, (key, item) => {
      const normalizedKey = normalizedCloudKey(key);
      if (normalizedKey && isSensitiveCloudKey(key)) {
        return '[redacted]';
      }
      if (typeof item === 'string' && /^data:image\//i.test(item)) {
        return `[image omitted: ${item.length} chars]`;
      }
      if (LARGE_IMAGE_KEY.test(normalizedKey) && typeof item === 'string' && item.length > 500) {
        return `[large payload omitted: ${item.length} chars]`;
      }
      if (typeof item === 'string' && item.length > CLOUD_STRING_LIMIT) {
        return `${item.slice(0, CLOUD_STRING_LIMIT)}\n[truncated ${item.length - CLOUD_STRING_LIMIT} chars for cloud persistence]`;
      }
      return item;
    }));
  } catch {
    return { unserializable: true };
  }
}

function cloudUrlEvidence(value) {
  try {
    const url = new URL(String(value || ''));
    if (!['http:', 'https:'].includes(url.protocol)) return {};
    return { url_origin: url.origin };
  } catch {
    return {};
  }
}

function cloudTerminalUrl(value, { strictSecretMode = false } = {}) {
  if (!strictSecretMode) return value;
  return cloudUrlEvidence(value).url_origin || '';
}

function redactVerifyFormValues(value) {
  try {
    return JSON.parse(JSON.stringify(value, (key, item) => (
      VERIFY_FORM_VALUE_KEYS.has(normalizedCloudKey(key).toLowerCase())
        ? '[redacted form value]'
        : item
    )));
  } catch {
    return { success: false, sensitivePayloadRedacted: true };
  }
}

// Every leaf a secret can be encoded in goes, not just strings: a six-digit OTP
// serialized as `verification_code: 481920` is a number, and no key pattern
// recognizes that field name. Booleans and null survive because neither can
// carry a credential — which is also what makes a strict structured run
// gradable, since a `true` outcome flag comes through intact. A strict run's
// structured output is therefore assertable on booleans only.
function redactStrictStructuredValues(value) {
  try {
    return JSON.parse(JSON.stringify(value, (_key, item) => {
      if (typeof item === 'string') return '[redacted strict value]';
      if (typeof item === 'number' || typeof item === 'bigint') return '[redacted strict number]';
      return item;
    }));
  } catch {
    return { sensitivePayloadRedacted: true };
  }
}

function cloudSafeUpdateData(type, data, { strictSecretMode = false } = {}) {
  if (!data || typeof data !== 'object') return data;
  const name = String(data.name || data.tool || '');
  if (strictSecretMode && CLOUD_STRICT_MODEL_TEXT_TYPES.has(type)) {
    return {
      ...data,
      ...(Object.hasOwn(data, 'content') ? { content: '[redacted strict text]' } : {}),
    };
  }
  if (strictSecretMode && CLOUD_STRICT_DROPPED_MESSAGE_TYPES.has(type)) {
    // Dropped rather than replaced so the run-level fallbacks below still pick
    // their own descriptive constant instead of storing a placeholder.
    const { message: _message, ...rest } = data;
    return rest;
  }
  if (!strictSecretMode && type === 'tool_call' && CLOUD_TEXT_ENTRY_TOOLS.has(name)) {
    const args = data.args && typeof data.args === 'object' ? data.args : {};
    return {
      ...data,
      args: {
        ...args,
        ...(Object.hasOwn(args, 'text') ? { text: '[redacted typed text]' } : {}),
        ...(Object.hasOwn(args, 'value') ? { value: '[redacted typed text]' } : {}),
      },
    };
  }
  if (strictSecretMode && type === 'tool_call' && name === 'fetch_url') {
    const args = data.args && typeof data.args === 'object' ? data.args : {};
    const method = String(args.method || '').toUpperCase();
    return {
      ...data,
      args: {
        ...(['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS'].includes(method) ? { method } : {}),
        ...cloudUrlEvidence(args.url),
        ...(Object.hasOwn(args, 'body') ? { body: '[redacted request body]' } : {}),
      },
    };
  }
  if (strictSecretMode && type === 'tool_result' && name === 'fetch_url') {
    const result = data.result && typeof data.result === 'object' ? data.result : {};
    return {
      ...data,
      result: {
        success: result.success === true,
        ...(Number.isFinite(Number(result.status)) ? { status: Number(result.status) } : {}),
        sensitivePayloadRedacted: true,
      },
    };
  }
  if (strictSecretMode && type === 'tool_result' && name === 'verify_form') {
    return {
      ...data,
      result: redactVerifyFormValues(data.result),
    };
  }
  if (strictSecretMode && type === 'tool_call' && name === 'done_json') {
    const args = data.args && typeof data.args === 'object' ? data.args : {};
    return {
      ...data,
      args: {
        ...args,
        ...(Object.hasOwn(args, 'result') ? { result: redactStrictStructuredValues(args.result) } : {}),
        ...(Object.hasOwn(args, 'summary') ? { summary: '[redacted strict summary]' } : {}),
      },
    };
  }
  if (strictSecretMode && type === 'tool_result' && name === 'done_json') {
    const result = data.result && typeof data.result === 'object' ? data.result : {};
    return {
      ...data,
      result: {
        ...result,
        ...(Object.hasOwn(result, 'result') ? { result: redactStrictStructuredValues(result.result) } : {}),
        ...(Object.hasOwn(result, 'cloudResult') ? { cloudResult: redactStrictStructuredValues(result.cloudResult) } : {}),
        ...(Object.hasOwn(result, 'invalidResult') ? { invalidResult: redactStrictStructuredValues(result.invalidResult) } : {}),
        ...(Object.hasOwn(result, 'summary') ? { summary: '[redacted strict summary]' } : {}),
      },
    };
  }
  if (strictSecretMode && type === 'tool_call') {
    const args = data.args && typeof data.args === 'object' ? data.args : {};
    const evidence = Object.fromEntries(Object.entries(args).filter(([key, value]) => (
      CLOUD_STRICT_ARG_EVIDENCE_KEYS.has(key) && (typeof value !== 'object' || value === null)
    )));
    return {
      ...data,
      args: { ...evidence, sensitiveArgsRedacted: true },
    };
  }
  if (strictSecretMode && type === 'tool_result' && !CLOUD_STRICT_STRUCTURED_RESULT_TOOLS.has(name)) {
    // Any read tool echoes back whatever was typed into the page, so success
    // and HTTP status are all a result may carry out of a strict run.
    const result = data.result && typeof data.result === 'object' ? data.result : {};
    return {
      ...data,
      result: {
        success: result.success === true,
        ...(Number.isFinite(Number(result.status)) ? { status: Number(result.status) } : {}),
        sensitivePayloadRedacted: true,
      },
    };
  }
  return data;
}

// Walks a raw tool result for string or numeric values sitting under a key the
// scrubber already treats as sensitive. Depth-bounded: a page read can be
// enormous, and this runs on every update.
function collectSensitiveStrings(value, into, depth = 0, sensitiveParent = false) {
  if (depth > 6 || into.length > CLOUD_STRICT_SECRET_VALUE_LIMIT) return;
  if (typeof value === 'string') {
    if (sensitiveParent) into.push(value);
    return;
  }
  if (typeof value === 'number') {
    if (sensitiveParent && Number.isFinite(value)) into.push(String(value));
    return;
  }
  if (Array.isArray(value)) {
    for (const item of value) collectSensitiveStrings(item, into, depth + 1, sensitiveParent);
    return;
  }
  if (!value || typeof value !== 'object') return;
  for (const [key, item] of Object.entries(value)) {
    collectSensitiveStrings(
      item,
      into,
      depth + 1,
      sensitiveParent || isSensitiveCloudKey(key),
    );
    if (into.length > CLOUD_STRICT_SECRET_VALUE_LIMIT) return;
  }
}

function isSensitiveUrlComponentKey(value) {
  const text = String(value || '');
  return isSensitiveCloudKey(text)
    || SENSITIVE_URL_COMPONENT_KEY.test(text)
    || /(?:Key|Code|Signature|Token|Secret|Password)$/.test(text);
}

function isSensitiveUrlPathLabel(value) {
  return SENSITIVE_URL_PATH_LABELS.has(normalizedCloudKey(value).toLowerCase());
}

// URL paths and queries are withheld wholesale from strict trace evidence, but
// the value registry must be narrower: registering `/profile` or `?tab=activity`
// as a secret corrupts legitimate caller-visible results. Remember userinfo,
// values under credential-like query keys, and path/hash components that either
// carry credential vocabulary themselves or follow an explicit credential label.
function collectUrlSecretStrings(value, into) {
  let url;
  try {
    url = new URL(String(value || ''));
  } catch {
    return;
  }
  if (!['http:', 'https:'].includes(url.protocol)) return;
  const add = (candidate) => {
    const text = String(candidate || '');
    if (text && into.length <= CLOUD_STRICT_SECRET_VALUE_LIMIT) into.push(text);
  };
  const addEncoded = (candidate) => {
    add(candidate);
    try {
      add(decodeURIComponent(String(candidate || '')));
    } catch {}
  };
  addEncoded(url.username);
  addEncoded(url.password);
  let followsSensitivePathLabel = false;
  for (const segment of url.pathname.split('/').filter(Boolean)) {
    let decoded = segment;
    try { decoded = decodeURIComponent(segment); } catch {}
    const isLabel = isSensitiveUrlPathLabel(decoded);
    if (followsSensitivePathLabel || (!isLabel && isSensitiveUrlComponentKey(decoded))) {
      addEncoded(segment);
    }
    followsSensitivePathLabel = isLabel;
  }
  for (const [key, item] of url.searchParams) {
    if (isSensitiveUrlComponentKey(key)) addEncoded(item);
  }
  const hash = url.hash.replace(/^#/, '');
  if (hash) {
    let decodedHash = hash;
    try { decodedHash = decodeURIComponent(hash); } catch {}
    let foundSensitiveHashParam = false;
    if (decodedHash.includes('=')) {
      const hashParams = new URLSearchParams(decodedHash.replace(/^\?/, ''));
      for (const [key, item] of hashParams) {
        if (!isSensitiveUrlComponentKey(key)) continue;
        foundSensitiveHashParam = true;
        addEncoded(item);
      }
    }
    if (!foundSensitiveHashParam
        && !isSensitiveUrlPathLabel(decodedHash)
        && isSensitiveUrlComponentKey(decodedHash)) {
      addEncoded(hash);
    }
  }
}

// URL credentials are not unique to fetch_url: navigate, new_tab, read tools,
// downloads, custom skills, and tool results can all carry URL-shaped fields.
// Walk only fields whose normalized name ends in url/urls, but follow arrays
// and nested containers below such a field so credential-like components in
// every concrete http(s) value are registered before later prose is published.
function collectUrlSecretsFromNamedFields(value, into, depth = 0, urlBearing = false) {
  if (depth > 6 || into.length > CLOUD_STRICT_SECRET_VALUE_LIMIT) return;
  if (typeof value === 'string') {
    if (urlBearing) collectUrlSecretStrings(value, into);
    return;
  }
  if (Array.isArray(value)) {
    for (const item of value) collectUrlSecretsFromNamedFields(item, into, depth + 1, urlBearing);
    return;
  }
  if (!value || typeof value !== 'object') return;
  for (const [key, item] of Object.entries(value)) {
    const normalizedKey = normalizedCloudKey(key).toLowerCase();
    collectUrlSecretsFromNamedFields(
      item,
      into,
      depth + 1,
      urlBearing || /urls?$/.test(normalizedKey),
    );
    if (into.length > CLOUD_STRICT_SECRET_VALUE_LIMIT) return;
  }
}

// Full URLs are trace-only sensitive in strict mode even when their individual
// path/query components are ordinary public data. Keep this registry separate
// from credential values so a repeated URL is removed from prose updates while
// a schema-valid result such as `{ section: 'profile' }` stays intact.
function collectUrlTraceStringsFromNamedFields(value, into, depth = 0, urlBearing = false) {
  if (depth > 6 || into.length > CLOUD_STRICT_SECRET_VALUE_LIMIT) return;
  if (typeof value === 'string') {
    if (!urlBearing) return;
    try {
      const url = new URL(value);
      if (!['http:', 'https:'].includes(url.protocol)) return;
      into.push(value);
      if (url.href !== value) into.push(url.href);
    } catch {}
    return;
  }
  if (Array.isArray(value)) {
    for (const item of value) collectUrlTraceStringsFromNamedFields(item, into, depth + 1, urlBearing);
    return;
  }
  if (!value || typeof value !== 'object') return;
  for (const [key, item] of Object.entries(value)) {
    const normalizedKey = normalizedCloudKey(key).toLowerCase();
    collectUrlTraceStringsFromNamedFields(
      item,
      into,
      depth + 1,
      urlBearing || /urls?$/.test(normalizedKey),
    );
    if (into.length > CLOUD_STRICT_SECRET_VALUE_LIMIT) return;
  }
}

// verify_form represents an input's identity and value as siblings, for
// example `{ name: 'api_key', value: 'secret' }`. The generic key walk above
// cannot connect those fields, so reuse the same credential detector that
// classifies fields when they are filled and register only that field record's
// value-bearing leaves.
function collectCredentialFieldValues(value, into, depth = 0) {
  if (depth > 6 || into.length > CLOUD_STRICT_SECRET_VALUE_LIMIT) return;
  if (Array.isArray(value)) {
    for (const item of value) collectCredentialFieldValues(item, into, depth + 1);
    return;
  }
  if (!value || typeof value !== 'object') return;
  const credential = isCredentialField({
    type: value.type,
    name: value.name,
    id: value.id,
    autocomplete: value.autocomplete,
    ariaLabel: value.ariaLabel ?? value.aria_label,
    placeholder: value.placeholder,
    labelText: value.labelText ?? value.label,
  }).sensitive;
  if (credential) {
    for (const [key, item] of Object.entries(value)) {
      if (!VERIFY_FORM_VALUE_KEYS.has(normalizedCloudKey(key).toLowerCase())) continue;
      if (typeof item === 'string') into.push(item);
      else if (typeof item === 'number' && Number.isFinite(item)) into.push(String(item));
    }
  }
  for (const item of Object.values(value)) {
    if (item && typeof item === 'object') collectCredentialFieldValues(item, into, depth + 1);
    if (into.length > CLOUD_STRICT_SECRET_VALUE_LIMIT) return;
  }
}

// A request body is a string argument, so the key-walk above cannot see into
// it. Both encodings a mutating call realistically uses are cheap to parse.
function collectRequestBodySecrets(body, into) {
  if (typeof body !== 'string' || !body) return false;
  // Do not silently skip a body that is too large for bounded inspection. The
  // caller marks the run as overflowed so every later scalar is redacted rather
  // than relying on the model not to repeat an unknown credential.
  if (body.length > WORKFLOW_PARAMETER_VALUE_LIMIT) return true;
  try {
    collectSensitiveStrings(JSON.parse(body), into);
    return false;
  } catch {
    // Not JSON — fall through to the form encoding.
  }
  try {
    for (const [key, value] of new URLSearchParams(body)) {
      if (isSensitiveCloudKey(key)) into.push(value);
    }
  } catch {
    // Undecodable body: nothing to register, and the argument is dropped anyway.
  }
  return false;
}

function redactWorkflowRuntimeValues(value, runtimeValues = [], label = '[workflow parameter]') {
  if (value == null) return value;
  const variants = new Set();
  for (const parameterValue of runtimeValues) {
    if (typeof parameterValue !== 'string' || !parameterValue.length) continue;
    variants.add(parameterValue);
    try {
      const componentEncoded = encodeURIComponent(parameterValue);
      variants.add(componentEncoded);
      variants.add(componentEncoded.replace(/%20/g, '+'));
      variants.add(encodeURI(parameterValue));
      const formEncoded = new URLSearchParams([['value', parameterValue]])
        .toString()
        .slice('value='.length);
      variants.add(formEncoded);
    } catch {
      // Raw replacement above still protects malformed strings that URI
      // encoders cannot represent (for example, lone UTF-16 surrogates).
    }
  }
  const values = [...variants]
    .sort((a, b) => b.length - a.length);
  if (!values.length) return value;
  const normalizePercentEscapes = input => input.replace(
    /%[0-9a-f]{2}/gi,
    match => match.toUpperCase(),
  );
  const redactString = (input) => values.reduce((text, parameterValue) => {
    const normalizedText = normalizePercentEscapes(text);
    const normalizedValue = normalizePercentEscapes(parameterValue);
    if (!normalizedText.includes(normalizedValue)) return text;
    let result = '';
    let offset = 0;
    let index = normalizedText.indexOf(normalizedValue, offset);
    while (index !== -1) {
      const boundaryMatch = parameterValue.length >= CLOUD_STRICT_SECRET_MIN_LENGTH
        || (
          (index === 0 || !/[A-Za-z0-9]/.test(normalizedText[index - 1]))
          && (
            index + normalizedValue.length === normalizedText.length
            || !/[A-Za-z0-9]/.test(normalizedText[index + normalizedValue.length])
          )
        );
      if (!boundaryMatch) {
        const nextOffset = index + normalizedValue.length;
        result += text.slice(offset, nextOffset);
        offset = nextOffset;
        index = normalizedText.indexOf(normalizedValue, offset);
        continue;
      }
      result += `${text.slice(offset, index)}${label}`;
      offset = index + parameterValue.length;
      index = normalizedText.indexOf(normalizedValue, offset);
    }
    return result + text.slice(offset);
  }, input);
  try {
    return JSON.parse(JSON.stringify(value, (_key, item) => (
      // A secret typed as text can come back as a JSON number — a six-digit OTP
      // is the obvious case. Match on the number's exact string form: a
      // substring rule would strike an unrelated `3` out of `481920`.
      typeof item === 'number' && values.includes(String(item))
        ? label
        : (typeof item === 'string' ? redactString(item) : item)
    )));
  } catch {
    return { unserializable: true };
  }
}

function serializedBytes(value) {
  return new TextEncoder().encode(JSON.stringify(value)).length;
}

function compactCloudRunForPersistence(run) {
  const row = scrubCloudValue(run);
  row.structured = row.structured ?? hasCloudOutputSchema(run?.outputSchema);
  if (serializedBytes(row) <= CLOUD_RUN_PERSIST_BYTES_LIMIT) return row;

  const omittedUpdates = Array.isArray(row.updates) ? row.updates.length : 0;
  row.updates = [];
  row.persistenceTruncated = { omittedUpdates };
  if (serializedBytes(row) <= CLOUD_RUN_PERSIST_BYTES_LIMIT) return row;

  row.content = '';
  row.outputSchema = null;
  row.persistenceTruncated.omittedContent = true;
  row.persistenceTruncated.omittedSchema = true;
  if (serializedBytes(row) <= CLOUD_RUN_PERSIST_BYTES_LIMIT) return row;

  delete row.result;
  row.persistenceTruncated.omittedResult = true;
  if (serializedBytes(row) <= CLOUD_RUN_PERSIST_BYTES_LIMIT) return row;

  return scrubCloudValue({
    runId: run?.runId,
    status: run?.status,
    workflowId: run?.workflowId || null,
    traceRunId: run?.traceRunId || null,
    parentRunId: run?.parentRunId || null,
    mode: run?.mode || 'act',
    permissionMode: run?.permissionMode || '',
    captchaDiagnostics: run?.captchaDiagnostics || null,
    tabId: run?.tabId,
    task: run?.task,
    structured: hasCloudOutputSchema(run?.outputSchema) || run?.structured === true,
    pendingInput: run?.pendingInput || null,
    summary: run?.summary,
    content: '',
    finalUrl: run?.finalUrl,
    error: run?.error,
    createdAt: run?.createdAt,
    updatedAt: run?.updatedAt,
    completedAt: run?.completedAt,
    updates: [],
    persistenceTruncated: { omittedUpdates, omittedResult: true, omittedSchema: true },
  });
}

/**
 * Scheduled jobs answer a cloud query over the same bridge as run updates, so
 * they need the same strict-secret treatment: a summarized job otherwise ships
 * `lastResult`, `lastError`, `pendingClarify`, `target.url`, and
 * `watch.lastObservation` — a child task's raw prompt and output — straight past
 * every redaction applied to the parent run. Strict mode keeps only structural
 * and enumerated fields; free text and URLs are dropped.
 */
export function cloudSafeScheduledJob(job, { strictSecretMode = false } = {}) {
  if (!job || !strictSecretMode) return job;
  return {
    id: job.id,
    kind: job.kind,
    source: job.source || null,
    status: job.status,
    scheduledAt: job.scheduledAt,
    nextRunAt: job.nextRunAt || job.scheduledAt,
    lastOutcome: job.lastOutcome || null,
    // A queued job the embedder's run gate holds says so (e.g. 'license_read_only').
    heldBy: job.heldBy || null,
    needsUserInput: job.needsUserInput === true,
    clarificationRequired: job.clarificationRequired === true,
    completedAt: job.completedAt || null,
    createdAt: job.createdAt,
    updatedAt: job.updatedAt,
    sensitiveFieldsRedacted: true,
  };
}

export function buildCloudPersistenceRows(runs) {
  const values = Array.isArray(runs) ? [...runs] : [...(runs?.values?.() || [])];
  const candidates = values
    .sort((a, b) => String(b?.createdAt || '').localeCompare(String(a?.createdAt || '')))
    .slice(0, CLOUD_RUN_LIMIT)
    .map(compactCloudRunForPersistence);
  const rows = [];
  let totalBytes = 2;
  for (const row of candidates) {
    const rowBytes = serializedBytes(row) + (rows.length ? 1 : 0);
    if (totalBytes + rowBytes > CLOUD_PERSIST_BYTES_LIMIT) continue;
    rows.push(row);
    totalBytes += rowBytes;
  }
  return rows;
}

function cloudSnapshot(run, { includeUpdates = true } = {}) {
  if (!run) return null;
  return {
    runId: run.runId,
    status: run.status,
    workflowId: run.workflowId || null,
    parentRunId: run.parentRunId || null,
    mode: run.mode || 'act',
    permissionMode: run.permissionMode || '',
    tabId: run.tabId,
    task: run.task,
    structured: run.structured ?? hasCloudOutputSchema(run.outputSchema),
    pendingInput: run.pendingInput || null,
    ...(run.captchaDiagnostics ? { captchaDiagnostics: run.captchaDiagnostics } : {}),
    result: run.result,
    persistenceTruncated: run.persistenceTruncated,
    summary: run.summary,
    content: run.content,
    finalUrl: run.finalUrl,
    error: run.error,
    createdAt: run.createdAt,
    updatedAt: run.updatedAt,
    completedAt: run.completedAt,
    updates: includeUpdates ? run.updates : undefined,
  };
}

function isUsableCloudTab(tab) {
  if (tab?.id == null) return false;
  try {
    // Chrome can leave an unpacked-extension startup tab's `url` empty while
    // exposing the loaded page through `pendingUrl`, even with status=complete.
    const url = new URL(tab.url || tab.pendingUrl || '');
    return ['http:', 'https:', 'file:'].includes(url.protocol) || url.href === 'about:blank';
  } catch {
    return false;
  }
}

export function createCloudRunController({
  chromeApi,
  agent,
  ensureOffscreen,
  sendIndicator = () => {},
  startRecording = null,
  stopRecording = null,
  workflowTrace = null,
  now = () => new Date(),
  makeRunId = () => `run_${globalThis.crypto.randomUUID()}`,
  fetchImpl = (...args) => globalThis.fetch(...args),
  // async () => null | { message, status?, code?, license? }: a refusal stops
  // the run before anything happens in the browser (see runGateRefusal).
  runGate = null,
} = {}) {
  const api = chromeApi;
  const runs = new Map();
  const startingTabs = new Set();
  // Workmate update drain. While armed, new runs are refused so the extension
  // folder can be swapped and the runtime reloaded without cutting a task off
  // halfway through a form. It self-clears: a Workmate that dies between
  // "prepare" and "reload" must not leave the browser refusing work forever.
  const UPDATE_DRAIN_TIMEOUT_MS = 5 * 60_000;
  let updateDrain = null;
  // Runs waiting on the embedder's run gate. They count as busy for the drain:
  // a gate may wait on the network, and an update must not slip in under a
  // run that is about to start.
  let admittingRuns = 0;
  let hydratePromise = null;
  let persistQueue = Promise.resolve();
  let persistTimer = null;

  const isoNow = () => now().toISOString();

  async function persist() {
    if (!api.storage?.session?.set) return;
    const rows = buildCloudPersistenceRows(runs);
    persistQueue = persistQueue
      .catch(() => {})
      .then(() => api.storage.session.set({ [CLOUD_RUN_STORAGE_KEY]: rows }));
    await persistQueue;
  }

  function schedulePersist() {
    if (persistTimer) return;
    persistTimer = setTimeout(() => {
      persistTimer = null;
      persist().catch(() => {});
    }, 100);
  }

  async function hydrate() {
    if (hydratePromise) return hydratePromise;
    hydratePromise = (async () => {
      if (!api.storage?.session?.get) return;
      const stored = await api.storage.session.get(CLOUD_RUN_STORAGE_KEY).catch(() => ({}));
      const rows = Array.isArray(stored?.[CLOUD_RUN_STORAGE_KEY]) ? stored[CLOUD_RUN_STORAGE_KEY] : [];
      let changed = false;
      for (const row of rows) {
        if (!row?.runId) continue;
        const rawUpdates = Array.isArray(row.updates) ? row.updates : [];
        let nextUpdateSeq = 0;
        const updates = rawUpdates.map((update) => {
          const candidate = Number(update?.seq);
          const seq = Number.isSafeInteger(candidate) && candidate > nextUpdateSeq
            ? candidate
            : nextUpdateSeq + 1;
          if (seq !== candidate) changed = true;
          nextUpdateSeq = seq;
          return { ...update, seq };
        });
        const restored = { ...row, updates, nextUpdateSeq };
        if (!TERMINAL_STATUSES.has(restored.status)) {
          const at = isoNow();
          restored.status = restored.status === 'aborting' ? 'aborted' : 'failed';
          restored.pendingInput = null;
          restored.error = restored.status === 'aborted'
            ? 'Run aborted when the AgentX WebMate service worker restarted.'
            : 'Run interrupted when the AgentX WebMate service worker restarted.';
          restored.updatedAt = at;
          restored.completedAt = at;
          changed = true;
        }
        runs.set(restored.runId, restored);
      }
      if (changed) await persist();
    })();
    return hydratePromise;
  }

  async function activateTab(tab) {
    if (!tab?.id) return tab;
    await api.tabs.update(tab.id, { active: true }).catch(() => {});
    if (tab.windowId != null && api.windows?.update) {
      await api.windows.update(tab.windowId, { focused: true }).catch(() => {});
    }
    return tab;
  }

  async function resolveTabId(requestedTabId) {
    if (requestedTabId != null && requestedTabId !== '') {
      const tab = await api.tabs.get(Number(requestedTabId));
      if (!isUsableCloudTab(tab)) throw new Error(`Tab ${requestedTabId} is not a controllable webpage.`);
      return tab.id;
    }

    const active = await api.tabs.query({ active: true, lastFocusedWindow: true });
    const activeTab = active.find(isUsableCloudTab);
    if (activeTab) return activeTab.id;

    const allTabs = await api.tabs.query({});
    const fallback = allTabs.find(isUsableCloudTab);
    if (fallback) return fallback.id;

    const created = await api.tabs.create({ url: 'about:blank', active: true });
    if (created?.id == null) throw new Error('Could not create a browser tab for the cloud run.');
    return created.id;
  }

  async function getTabUrl(tabId) {
    try {
      return (await api.tabs.get(tabId))?.url || '';
    } catch {
      return '';
    }
  }

  // Kept out of the run object so a literal secret can never reach session
  // storage or a persistence row. Dropped when the run leaves the map.
  const strictSecretValues = new Map();
  const strictTraceValues = new Map();
  const strictSecretOverflowRuns = new Set();
  const strictTraceOverflowRuns = new Set();

  function rememberStrictCandidates(run, candidates, registry, overflowRuns) {
    if (!candidates.length) return;
    const known = registry.get(run.runId) || [];
    for (const candidate of candidates) {
      if (typeof candidate !== 'string') continue;
      const shortNumericSecret = /^\d{1,3}$/.test(candidate);
      if (candidate.length < CLOUD_STRICT_SECRET_MIN_LENGTH && !shortNumericSecret) continue;
      if (candidate.length > WORKFLOW_PARAMETER_VALUE_LIMIT) continue;
      if (known.includes(candidate)) continue;
      if (known.length >= CLOUD_STRICT_SECRET_VALUE_LIMIT) {
        // Never evict an earlier credential or trace-only URL and silently
        // expose it later. Losing free-text utility is preferable to leakage.
        overflowRuns.add(run.runId);
        break;
      }
      known.push(candidate);
    }
    if (known.length) registry.set(run.runId, known);
  }

  // Whatever a strict run types into a page is a value the caller must never
  // read back, wherever it later resurfaces — a clarification question, a
  // warning, a captcha diagnostic. Remember it here, before the redactors drop
  // the argument that carried it.
  function rememberStrictSecrets(run, type, data) {
    const name = String(data?.name || data?.tool || '');
    const candidates = [];
    const traceCandidates = [];
    if (type === 'tool_call') {
      const args = data?.args && typeof data.args === 'object' ? data.args : {};
      if (CLOUD_TEXT_ENTRY_TOOLS.has(name)) candidates.push(args.text, args.value);
      collectUrlSecretsFromNamedFields(args, candidates);
      collectUrlTraceStringsFromNamedFields(args, traceCandidates);
      // A credential does not have to be typed into a page to exist. The
      // disposable-signup scenario mints its account password inside the JSON
      // body of `POST /accounts` and never types it, so registering only
      // text-entry arguments left it unknown to the value redactor.
      collectSensitiveStrings(args, candidates);
      if (collectRequestBodySecrets(args.body, candidates)) {
        strictSecretOverflowRuns.add(run.runId);
      }
    } else if (type === 'tool_result') {
      // The value under a sensitive key is already known to be a secret; the
      // key-based scrubber only masks it in place, so register the literal and
      // strike it from later prose as well.
      //
      // Known limit: a secret the model only ever *reads* out of an
      // unremarkable field — an OTP in the body text of an inbox message — is
      // never seen here in a form this can recognize, so a clarification that
      // quotes it is covered by the strict system prompt alone. Closing that
      // would mean either blanking clarification text, which makes a strict run
      // unanswerable, or entropy guessing at prose.
      collectSensitiveStrings(data?.result, candidates);
      collectUrlSecretsFromNamedFields(data?.result, candidates);
      collectUrlTraceStringsFromNamedFields(data?.result, traceCandidates);
      if (name === 'verify_form') collectCredentialFieldValues(data?.result, candidates);
    }
    rememberStrictCandidates(run, candidates, strictSecretValues, strictSecretOverflowRuns);
    rememberStrictCandidates(run, traceCandidates, strictTraceValues, strictTraceOverflowRuns);
  }

  function redactStrictSecretValues(run, value, strictSecretMode) {
    if (!strictSecretMode) return value;
    if (strictSecretOverflowRuns.has(run.runId)) return redactStrictStructuredValues(value);
    const known = strictSecretValues.get(run.runId);
    if (!known?.length) return value;
    return redactWorkflowRuntimeValues(value, known, '[redacted strict value]');
  }

  function redactStrictTraceValues(run, value, strictSecretMode) {
    const withoutSecrets = redactStrictSecretValues(run, value, strictSecretMode);
    if (!strictSecretMode || strictSecretOverflowRuns.has(run.runId)) return withoutSecrets;
    if (strictTraceOverflowRuns.has(run.runId)) return redactStrictStructuredValues(withoutSecrets);
    const known = strictTraceValues.get(run.runId);
    if (!known?.length) return withoutSecrets;
    return redactWorkflowRuntimeValues(withoutSecrets, known, '[redacted strict URL]');
  }

  // Terminal prose reaches the caller by the same two routes as an update row,
  // so it takes both secret and trace-only URL redaction. A structured
  // `run.result` is handled separately below and takes only credential-value
  // redaction so ordinary schema-valid URL components remain usable.
  function redactStrictTerminal(run, value, strictSecretMode) {
    return redactStrictTraceValues(run, value, strictSecretMode);
  }

  function pushUpdate(run, type, data, runtimeValues = []) {
    run.updatedAt = isoNow();
    const previous = run.updates.at(-1);
    const strictSecretMode = agent.strictSecretMode === true;
    if (strictSecretMode) rememberStrictSecrets(run, type, data);
    // Consecutive text_delta events upsert the same seq: content grows in place
    // and ts advances. Full-array pollers are fine; append-only / seq-cursor
    // clients must re-read that row (or take a full snapshot) rather than
    // assuming each seq is immutable.
    if (type === 'text_delta' && previous?.type === 'text_delta') {
      // Deltas must pass through the same redaction as any other update: this
      // branch used to append raw model output straight onto the stored row.
      const safeDelta = cloudSafeUpdateData(type, data, { strictSecretMode });
      previous.data = scrubCloudValue(redactStrictTraceValues(run, redactWorkflowRuntimeValues({
        ...previous.data,
        content: strictSecretMode
          ? (safeDelta?.content || '')
          : `${previous.data?.content || ''}${safeDelta?.content || ''}`,
      }, runtimeValues), strictSecretMode));
      previous.ts = run.updatedAt;
      schedulePersist();
      return;
    }
    run.nextUpdateSeq = (Number(run.nextUpdateSeq) || 0) + 1;
    const safeData = cloudSafeUpdateData(type, data, { strictSecretMode });
    const scrubbedData = scrubCloudValue(
      redactStrictTraceValues(run, redactWorkflowRuntimeValues(safeData, runtimeValues), strictSecretMode),
    );
    run.updates.push({ seq: run.nextUpdateSeq, type, data: scrubbedData, ts: run.updatedAt });
    if (run.updates.length > CLOUD_UPDATE_LIMIT) {
      run.updates.splice(0, run.updates.length - CLOUD_UPDATE_LIMIT);
    }
    if (type === 'tool_result' && scrubbedData?.name === 'done_json') {
      const result = data.result || {};
      const safeResult = scrubbedData.result || {};
      // Two different jobs, so two different redactors. The update row above is
      // trace and persistence with no contract to honour, and takes the blunt
      // leaf-type redaction. `run.result` and `run.summary` are the caller's
      // answer — the schema they asked for — so they take value redaction:
      // registered credentials are struck and everything else the contract
      // declares survives. Redacting those by leaf type returned `completed`
      // with every string and number replaced by a placeholder, which satisfies
      // strict mode by making the run useless.
      const publicSummary = strictSecretMode
        ? redactStrictTraceValues(run, result.summary, true)
        : safeResult.summary;
      if (result.cloudFailed) {
        run.status = 'failed';
        run.error = safeResult.error || 'done_json failed';
        run.summary = publicSummary || run.summary;
      } else if (Object.prototype.hasOwnProperty.call(result, 'cloudResult')) {
        run.result = strictSecretMode
          ? redactStrictSecretValues(run, result.cloudResult, true)
          : result.cloudResult;
        run.summary = publicSummary || run.summary;
      }
    }
    if (type === 'captcha_gate') {
      // Keep the latest sanitized frame/vendor snapshot at run level so it
      // survives the rolling 200-update window in exported cloud traces.
      run.captchaDiagnostics = { ...scrubbedData, observedAt: run.updatedAt };
    }
    if (type === 'clarify' && scrubbedData?.clarifyId && !TERMINAL_STATUSES.has(run.status)) {
      run.status = 'needs_user_input';
      run.pendingInput = scrubbedData;
    }
    if (type === 'run_status'
        && ['clarification_required', 'captcha_manual_required'].includes(scrubbedData?.status)
        && run.status !== 'aborting'
        && run.status !== 'aborted') {
      run.status = 'failed';
      run.error = scrubbedData.message
        || (scrubbedData.status === 'captcha_manual_required'
          ? 'Cloud run stopped because manual CAPTCHA completion is required.'
          : 'Cloud run stopped because explicit clarification authorization is required.');
      run.pendingInput = null;
    }
    if (type === 'plan_review' && run.status === 'running') {
      run.status = 'failed';
      run.error = 'Managed cloud runs cannot wait for interactive plan review.';
      agent.abort(run.tabId);
    }
    schedulePersist();
  }

  function validateWorkflowParameters(workflow, input) {
    if (!input || typeof input !== 'object' || Array.isArray(input)) {
      throw cloudRunError('`parameters` must be an object.', 400);
    }
    const descriptors = new Map((workflow.parameters || []).map(parameter => [parameter.id, parameter]));
    const parameters = Object.create(null);
    for (const [id, value] of Object.entries(input)) {
      if (!descriptors.has(id)) throw cloudRunError(`Unknown workflow parameter: ${id}`, 400);
      if (typeof value !== 'string') throw cloudRunError(`Workflow parameter ${id} must be a string.`, 400);
      if (value.length > WORKFLOW_PARAMETER_VALUE_LIMIT) {
        throw cloudRunError(`Workflow parameter ${id} exceeds ${WORKFLOW_PARAMETER_VALUE_LIMIT} characters.`, 400);
      }
      parameters[id] = value;
    }
    for (const descriptor of descriptors.values()) {
      if (descriptor.required !== false && !Object.hasOwn(parameters, descriptor.id)) {
        throw cloudRunError(`Missing workflow parameter: ${descriptor.id}`, 400);
      }
    }
    return parameters;
  }

  function drainRefusal() {
    return cloudRunError(
      'AgentX WebMate is about to update itself and is not taking new runs; retry in a moment.',
      503,
    );
  }

  async function startRun(msg = {}) {
    await hydrate();
    if (updateDrain) throw drainRefusal();
    const suppliedRunId = msg.runId ?? msg.run_id;
    const requestedRunId = suppliedRunId == null ? '' : String(suppliedRunId).trim();
    const parentRunId = String(msg.parentRunId || msg.parent_run_id || '').trim() || null;
    let parentRun = null;
    let requestedTabId = msg.tabId ?? msg.tab_id;
    if (parentRunId) {
      parentRun = runs.get(parentRunId) || null;
      if (parentRun) {
        if (!TERMINAL_STATUSES.has(parentRun.status)) {
          throw cloudRunError('Parent cloud run must be finished before it can be continued.', 409);
        }
        const existingChild = [...runs.values()].find(candidate => candidate.parentRunId === parentRunId);
        if (existingChild) {
          throw cloudRunError(`Cloud run has already been continued as ${existingChild.runId}.`, 409);
        }
        requestedTabId = parentRun.tabId;
      } else if (requestedTabId == null || requestedTabId === '') {
        throw cloudRunError('Parent cloud run is no longer available and has no saved tab.', 409);
      }
    }
    // Every refusal comes before resolveTabId: a run that cannot start must not
    // first activate — and possibly open — a tab in front of the user. The
    // gate goes first: an account that may not run at all (AgentX read-only
    // license) should hear that, not "sign in", when it also has no key.
    admittingRuns += 1;
    let gateRefusal;
    try {
      gateRefusal = await runGateRefusal(runGate);
    } finally {
      admittingRuns -= 1;
    }
    if (gateRefusal) throw gateRefusal;
    // A Workmate update may have started draining while the gate answered.
    if (updateDrain) throw drainRefusal();
    const unusableProvider = describeUnusableProvider(agent);
    if (unusableProvider) throw cloudRunError(unusableProvider, 428);
    const permissionMode = cloudRunPermissionMode(msg, parentRun);
    const tabId = await resolveTabId(requestedTabId);
    const workflow = msg._workflow || null;
    const mode = workflow ? 'act' : normalizeCloudRunMode(msg.mode, parentRun?.mode || 'act');
    const workflowParameters = msg._workflowParameters || {};
    const workflowParameterValues = workflow ? Object.values(workflowParameters) : [];
    const redactWorkflowValue = value => redactWorkflowRuntimeValues(value, workflowParameterValues);
    const task = workflow
      ? `Run saved workflow: ${workflow.name}`
      : String(msg.task || msg.text || '').trim();
    if (!task) throw new Error('cloud_run requires `task`.');
    if (startingTabs.has(tabId) || agent.isRunning(tabId)) {
      throw new Error(`Tab ${tabId} already has an active AgentX WebMate run.`);
    }

    const apiMutationsAllowed = msg.apiMutationsAllowed === true || msg.api_mutations_allowed === true;
    if (apiMutationsAllowed && mode !== 'act') {
      throw cloudRunError('API mutation permission requires cloud_run mode `act`.', 400);
    }
    const grantApiMutationsForRun = apiMutationsAllowed
      && agent.isApiMutationsAllowed?.(tabId) !== true;
    const outputSchema = workflow
      ? null
      : msg.outputSchema ?? msg.output_schema ?? msg.responseFormat?.schema ?? msg.response_format?.schema ?? null;
    const structured = hasCloudOutputSchema(outputSchema);
    const runId = requestedRunId || String(makeRunId());
    // Cloud-assigned IDs are valid correlation keys, but they must not replace
    // an active or persisted run. Besides losing the older run from status
    // queries, replacement aliases both runs' strict-secret registries; the
    // first run to finish would then clear the second run's redaction state.
    if (runs.has(runId)) {
      throw cloudRunError(`Cloud run ${runId} already exists.`, 409);
    }
    startingTabs.add(tabId);
    try {
      await agent.assertRunStartAllowed?.(tabId, 'cloud', { cloudRun: true });
      const targetTab = await api.tabs.get(tabId);
      await activateTab(targetTab);
    } catch (error) {
      startingTabs.delete(tabId);
      throw error;
    }
    const createdAt = isoNow();
    const run = {
      runId,
      status: 'running',
      workflowId: workflow?.id || null,
      traceRunId: null,
      parentRunId,
      mode,
      permissionMode,
      tabId,
      task,
      structured,
      outputSchema,
      capture: msg.capture === 'video' ? 'video' : 'none',
      result: undefined,
      summary: '',
      content: '',
      finalUrl: '',
      error: '',
      pendingInput: null,
      updates: [],
      nextUpdateSeq: 0,
      createdAt,
      updatedAt: createdAt,
      completedAt: null,
    };
    runs.set(run.runId, run);
    try {
      await persist();
    } catch (error) {
      runs.delete(run.runId);
      startingTabs.delete(tabId);
      throw error;
    }

    (async () => {
      let recordingId = null;
      const strictSecretMode = agent.strictSecretMode === true;
      try {
        // A continuation starts only after its parent has finished, so the
        // agent's active-run map cannot identify the parent here. The cloud
        // run record keeps the actual trace id; resolve its session from that
        // trace instead of attaching the tab's potentially unrelated session.
        const parentTraceRunId = parentRun?.traceRunId || null;
        let parentTraceSessionId = null;
        if (parentTraceRunId && typeof workflowTrace?.getRun === 'function') {
          try {
            const parentTrace = await workflowTrace.getRun(parentTraceRunId);
            parentTraceSessionId = parentTrace?.conversationId || null;
          } catch { /* lineage lookup is best-effort and must not fail a run */ }
        }
        if (run.capture === 'video') {
          try {
            if (!startRecording || !stopRecording) throw new Error('Cloud run video capture is unavailable.');
            const recording = await startRecording(tabId, {
              video: true,
              mic: false,
              showBanner: false,
              filename: `agentx-webmate-ci-${run.runId}.webm`,
            });
            if (!recording?.ok) throw new Error(recording?.error || 'Cloud run video capture could not start.');
            recordingId = recording.state?.recordingId || null;
          } catch (captureError) {
            pushUpdate(run, 'capture_error', {
              kind: 'video',
              message: captureError?.message || String(captureError),
            });
            throw captureError;
          }
          pushUpdate(run, 'artifact_started', {
            kind: 'video',
            filename: `agentx-webmate-ci-${run.runId}.webm`,
          });
        }
        if (grantApiMutationsForRun) agent.setTemporaryApiMutationsAllowed(tabId, true);
        sendIndicator(tabId, 'WB_SHOW_AGENT_INDICATORS');
        const publishUpdate = (type, data) => pushUpdate(
          run,
          type,
          workflow && type === 'text_delta'
            ? { ...(data || {}), content: '[workflow output redacted]' }
            : data,
          workflowParameterValues,
        );
        let content;
        if (workflow) {
          const replay = await agent.replaySavedWorkflow(
            tabId,
            workflow,
            workflowParameters,
            publishUpdate,
            { cloudRun: true, independentRun: true },
          );
          content = redactWorkflowValue(replay.summary || '');
          run.summary = redactWorkflowValue(replay.summary || run.summary);
          if (replay.status === 'fallback') {
            pushUpdate(run, 'workflow_fallback', {
              workflowId: workflow.id,
              stepIndex: replay.stepIndex,
              reason: replay.reason,
            });
            content = redactWorkflowValue(await agent.processMessage(
              tabId, replay.prompt, publishUpdate, 'act', [], {
                cloudRun: true,
                independentRun: true,
                preserveRichTextToolbarAudit: true,
                permissionMode,
              },
            ));
          } else if (replay.status === 'stopped') {
            run.status = 'failed';
            run.error = redactWorkflowValue(
              replay.summary || replay.reason || 'Saved workflow stopped safely.'
            );
          }
        } else {
          content = await agent.processMessage(tabId, task, publishUpdate, mode, [], {
            cloudRun: true,
            independentRun: true,
            apiMutationsDenied: mode === 'ask',
            permissionMode,
            outputSchema,
            onTraceStarted(traceRunId) {
              run.traceRunId = traceRunId;
              schedulePersist();
            },
            parentRunId: parentTraceRunId,
            parentSessionId: parentTraceSessionId,
          });
        }
        run.pendingInput = null;
        // Terminal fields are published over the bridge and persisted just like
        // update rows, so they get the same strict treatment — structured or
        // not. An unstructured strict run used to return its final answer raw,
        // which is where a model is most likely to repeat the credential it was
        // told not to. Value redaction rather than blanking, because for an
        // unstructured run this text *is* the result: the answer survives with
        // the literal struck.
        run.content = strictSecretMode && structured
          ? (run.summary || '[redacted strict structured completion]')
          : redactStrictTerminal(run, redactWorkflowValue(content), strictSecretMode);
        run.finalUrl = cloudTerminalUrl(redactWorkflowValue(await getTabUrl(tabId)), { strictSecretMode });
        if (run.status === 'aborting') {
          run.status = 'aborted';
          run.error = run.error || 'Aborted by cloud_abort.';
        } else if (run.status !== 'failed') {
          if (structured && run.result === undefined) {
            run.status = 'failed';
            run.error = 'Structured cloud run finished without a valid done_json result.';
          } else {
            run.status = 'completed';
            if (!structured) {
              run.result = redactStrictTerminal(run, redactWorkflowValue(content), strictSecretMode);
            }
          }
        }
      } catch (error) {
        run.pendingInput = null;
        run.status = run.status === 'aborting' ? 'aborted' : 'failed';
        run.error = redactStrictTerminal(
          run, redactWorkflowValue(error?.message || String(error)), strictSecretMode,
        );
        run.finalUrl = cloudTerminalUrl(redactWorkflowValue(await getTabUrl(tabId)), { strictSecretMode });
      } finally {
        startingTabs.delete(tabId);
        // The bridge flag is a run-scoped grant, not the sidebar's persistent
        // /allow-api setting. Revoke only permission this run added; preserve a
        // pre-existing per-conversation or global user grant.
        if (grantApiMutationsForRun) agent.setTemporaryApiMutationsAllowed(tabId, false);

        // Do not expose a terminal status until the requested recording has
        // finished flushing to Downloads; pollers use terminality as the cue
        // that traces and artifacts are complete.
        const terminalStatus = recordingId && TERMINAL_STATUSES.has(run.status)
          ? run.status
          : null;
        if (terminalStatus) run.status = 'running';
        if (recordingId) {
          try {
            const capture = await stopRecording({ expectedRecordingId: recordingId });
            if (!capture?.ok) throw new Error(capture?.error || 'Cloud run video capture could not stop.');
            pushUpdate(run, 'artifact', {
              kind: 'video',
              filename: capture.filename || `agentx-webmate-ci-${run.runId}.webm`,
            });
          } catch (captureError) {
            pushUpdate(run, 'capture_error', {
              kind: 'video',
              message: captureError?.message || String(captureError),
            });
          }
        }
        if (terminalStatus) run.status = terminalStatus;
        run.completedAt = isoNow();
        run.updatedAt = run.completedAt;
        // The run is over, so nothing more can quote these; do not hold the
        // literals in memory any longer than the run that typed them.
        strictSecretValues.delete(run.runId);
        strictTraceValues.delete(run.runId);
        strictSecretOverflowRuns.delete(run.runId);
        strictTraceOverflowRuns.delete(run.runId);
        sendIndicator(tabId, 'WB_HIDE_AGENT_INDICATORS');
        await persist().catch(() => {});
      }
    })();

    return cloudSnapshot(run, { includeUpdates: false });
  }

  async function startWorkflowRun(msg = {}) {
    const workflow = normalizeSavedWorkflow(msg.workflow);
    if (!workflow) throw cloudRunError('Saved workflow is missing or invalid.', 400);
    if (msg.parentRunId || msg.parent_run_id) {
      throw cloudRunError('Saved workflow runs cannot be continuations.', 400);
    }
    const parameters = validateWorkflowParameters(
      workflow,
      msg.parameters ?? {},
    );
    return startRun({
      ...msg,
      task: '',
      text: '',
      outputSchema: null,
      output_schema: null,
      _workflow: workflow,
      _workflowParameters: parameters,
    });
  }

  async function compileWorkflow(msg = {}) {
    await hydrate();
    const runId = String(msg.runId || msg.run_id || '').trim();
    const name = String(msg.name || '').trim();
    if (!runId) return { ok: false, status: 400, reason: 'run_required', warnings: [] };
    if (!name) return { ok: false, status: 400, reason: 'name_required', warnings: [] };
    const run = runs.get(runId);
    if (!run) return { ok: false, status: 404, reason: 'run_not_found', warnings: [] };
    if (run.workflowId) {
      return { ok: false, status: 422, reason: 'workflow_run_not_compilable', warnings: [] };
    }
    if (run.status !== 'completed') {
      return { ok: false, status: 409, reason: 'successful_run_required', warnings: [] };
    }
    if (!run.traceRunId || !workflowTrace) {
      return { ok: false, status: 409, reason: 'trace_unavailable', warnings: [] };
    }
    let compiled = null;
    for (let attempt = 0; attempt < 10; attempt += 1) {
      compiled = await compileSuccessfulWorkflowByRunId(workflowTrace, {
        runId: run.traceRunId,
        name,
      });
      if (compiled.workflow || compiled.reason !== 'successful_run_required') break;
      await new Promise(resolve => setTimeout(resolve, 50));
    }
    if (!compiled?.workflow) {
      return {
        ok: false,
        status: compiled?.reason === 'no_replayable_steps' ? 422 : 409,
        reason: compiled?.reason || 'workflow_compilation_failed',
        warnings: compiled?.warnings || [],
      };
    }
    return { ok: true, workflow: compiled.workflow, warnings: compiled.warnings || [] };
  }

  async function status(msg = {}) {
    await hydrate();
    const runId = msg.runId || msg.run_id;
    if (!runId) return { runs: [...runs.values()].map(run => cloudSnapshot(run, { includeUpdates: false })) };
    const run = runs.get(runId);
    if (!run) throw new Error('Unknown cloud run.');
    return cloudSnapshot(run);
  }

  async function abort(msg = {}) {
    await hydrate();
    const run = runs.get(msg.runId || msg.run_id);
    if (!run) throw new Error('Unknown cloud run.');
    if (run.status === 'running' || run.status === 'needs_user_input') {
      run.status = 'aborting';
      run.pendingInput = null;
      run.error = 'Abort requested.';
      run.updatedAt = isoNow();
      agent.abort(run.tabId);
      await persist();
    }
    return cloudSnapshot(run);
  }

  async function respond(msg = {}) {
    await hydrate();
    const run = runs.get(msg.runId || msg.run_id);
    if (!run) throw cloudRunError('Unknown cloud run.', 404);
    if (run.status !== 'needs_user_input') {
      throw cloudRunError('Cloud run is not waiting for user input.', 409);
    }
    const clarifyId = String(msg.clarifyId || msg.clarify_id || '').trim();
    if (!clarifyId) throw cloudRunError('cloud_respond requires `clarify_id`.', 400);
    const pendingClarifyId = String(run.pendingInput?.clarifyId || run.pendingInput?.clarify_id || '').trim();
    if (!pendingClarifyId || clarifyId !== pendingClarifyId) {
      throw cloudRunError('Clarification is no longer pending for this cloud run.', 409);
    }
    const answer = String(msg.answer ?? '').trim();
    if (!answer) throw cloudRunError('cloud_respond requires `answer`.', 400);
    if (!agent.submitClarifyResponse(run.tabId, clarifyId, answer, 'cloud_api')) {
      throw cloudRunError('Clarification is no longer available in the active AgentX WebMate run.', 409);
    }
    run.status = 'running';
    run.pendingInput = null;
    run.error = '';
    pushUpdate(run, 'clarify_response', { clarifyId, source: 'cloud_api' });
    await persist();
    return cloudSnapshot(run);
  }

  /** Runs that would be cut off by a runtime reload right now. */
  function busyRunCount() {
    let busy = startingTabs.size + admittingRuns;
    for (const run of runs.values()) {
      if (!TERMINAL_STATUSES.has(run.status)) busy += 1;
    }
    return busy;
  }

  function clearUpdateDrain() {
    if (updateDrain?.timer) clearTimeout(updateDrain.timer);
    updateDrain = null;
  }

  // `workmate_prepare_update` from the bridge. Idempotent: Workmate re-sends it
  // while polling for `busy` to reach 0, then follows with `workmate_reload`.
  // `{ resume: true }` cancels the drain when the update is called off.
  async function prepareUpdate(msg = {}) {
    await hydrate();
    if (msg.resume === true || msg.cancel === true) {
      clearUpdateDrain();
      return { ok: true, draining: false, busy: busyRunCount() };
    }
    if (!updateDrain) {
      updateDrain = {
        requestedAt: isoNow(),
        timer: setTimeout(clearUpdateDrain, UPDATE_DRAIN_TIMEOUT_MS),
      };
    }
    return { ok: true, draining: true, busy: busyRunCount() };
  }

  /**
   * The packaged workmate.json, or null for a developer/store install. A
   * missing file is the normal dev case; a present but broken one is reported
   * so the bridge status line can show it.
   */
  async function readWorkmateConfig() {
    let response;
    try {
      response = await fetchImpl(api.runtime.getURL(WORKMATE_CONFIG_PATH), { cache: 'no-store' });
    } catch {
      return { workmate: null, workmateError: '' };
    }
    if (!response?.ok) return { workmate: null, workmateError: '' };
    let text;
    try {
      text = await response.text();
    } catch (error) {
      return { workmate: null, workmateError: `workmate.json could not be read: ${error?.message || error}` };
    }
    const { config, error } = parseWorkmateConfig(text);
    return { workmate: config, workmateError: error };
  }

  /** Whether a stored AgentX session record counts as signed in (presence only; validity is the service's business). */
  function sessionSignedIn(session) {
    return Boolean(session && typeof session === 'object' && session.idToken && session.user?.subject);
  }

  /**
   * The per-profile id sent as `hello.instanceId` (see WORKMATE_INSTANCE_ID_KEY).
   * Minted on first use and kept in chrome.storage.local; '' when storage is
   * unavailable, in which case the server falls back to a per-socket id.
   */
  async function bridgeInstanceId() {
    try {
      const stored = await api.storage.local.get([WORKMATE_INSTANCE_ID_KEY]);
      const existing = stored?.[WORKMATE_INSTANCE_ID_KEY];
      if (typeof existing === 'string' && existing.trim()) return existing.trim();
      const minted = globalThis.crypto.randomUUID();
      await api.storage.local.set({ [WORKMATE_INSTANCE_ID_KEY]: minted });
      return minted;
    } catch {
      return '';
    }
  }

  /**
   * `cloud_bridge_identity` — what the offscreen bridge needs to introduce
   * itself in `hello`, gathered here because an offscreen document has no
   * chrome.* API beyond runtime messaging: manifest version, whether an AgentX
   * session is signed in (null when storage cannot answer — never guessed),
   * the per-profile instance id, and the parsed workmate.json.
   */
  async function bridgeIdentity() {
    let version = '';
    try {
      version = String(api.runtime.getManifest?.()?.version || '');
    } catch { /* not available in this context */ }
    let signedIn = null;
    try {
      const stored = await api.storage.local.get([WORKMATE_SESSION_STORAGE_KEY]);
      signedIn = sessionSignedIn(stored?.[WORKMATE_SESSION_STORAGE_KEY]);
    } catch { /* storage unavailable */ }
    const instanceId = await bridgeInstanceId();
    const { workmate, workmateError } = await readWorkmateConfig();
    return { version, signedIn, instanceId, workmate, workmateError };
  }

  // A sign-in or sign-out must reach the server without waiting for the next
  // hello: Workmate shows "connected · not signed in" from the last hello and
  // decides from it whether to offer sign-in. The offscreen document cannot
  // watch storage itself, so the change is relayed to it here and it sends a
  // `session` frame on the open socket (docs/workmate-integration.md).
  api.storage?.onChanged?.addListener?.((changes, area) => {
    if (area !== 'local' || !changes || !(WORKMATE_SESSION_STORAGE_KEY in changes)) return;
    const signedIn = sessionSignedIn(changes[WORKMATE_SESSION_STORAGE_KEY]?.newValue);
    try {
      Promise.resolve(api.runtime.sendMessage({ type: 'cloud-bridge-session', signedIn })).catch(() => {});
    } catch { /* no offscreen document to tell */ }
  });

  async function startBridge(url = DEFAULT_CLOUD_BRIDGE_URL) {
    await ensureOffscreen();
    return api.runtime.sendMessage({ type: 'cloud-bridge-start', url: normalizeCloudBridgeUrl(url) });
  }

  async function stopBridge() {
    return api.runtime.sendMessage({ type: 'cloud-bridge-stop' });
  }

  async function bridgeStatus() {
    await ensureOffscreen();
    return api.runtime.sendMessage({ type: 'cloud-bridge-status' });
  }

  // Called on install, on browser start, on every service-worker cold start, on
  // the watchdog alarm, and whenever the two storage keys change. Everything
  // below it is idempotent: `startBridge` re-creates the offscreen document only
  // when it is missing, and the offscreen client no-ops when its socket is
  // already open. That is what makes the watchdog safe to fire on a timer.
  async function syncBridge() {
    const stored = await api.storage.local.get([CLOUD_BRIDGE_ENABLED_KEY, CLOUD_BRIDGE_URL_KEY]);
    if (!isCloudBridgeEnabled(stored)) {
      return stopBridge().catch(() => ({ enabled: false, connected: false }));
    }
    return startBridge(cloudBridgeUrlFrom(stored));
  }

  return {
    runs,
    isRunning: (tabId) => startingTabs.has(tabId),
    startRun,
    startWorkflowRun,
    compileWorkflow,
    status,
    respond,
    abort,
    startBridge,
    stopBridge,
    bridgeStatus,
    syncBridge,
    bridgeIdentity,
    prepareUpdate,
    isDraining: () => updateDrain !== null,
    hydrate,
  };
}
